//
// Created by h3root on 11/12/21.
//

#ifndef LAB1_CLOCK_H
#define LAB1_CLOCK_H
void clock_set_next_event();
#endif //LAB1_CLOCK_H
